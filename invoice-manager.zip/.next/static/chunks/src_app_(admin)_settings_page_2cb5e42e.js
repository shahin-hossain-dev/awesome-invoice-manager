(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_967383ab._.js",
  "static/chunks/src_app_(admin)_8c3dcc6f._.js"
],
    source: "dynamic"
});
