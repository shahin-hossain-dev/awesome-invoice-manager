(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_fbcec262._.js",
  "static/chunks/node_modules_recharts_es6_59a2ad4f._.js",
  "static/chunks/node_modules_ab608d1e._.js",
  "static/chunks/src_app_(admin)_components_4fc2455a._.js"
],
    source: "dynamic"
});
