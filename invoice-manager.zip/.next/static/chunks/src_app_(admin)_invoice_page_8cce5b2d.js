(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_521eaf3e._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_next_f119b041._.js",
  "static/chunks/node_modules_sweetalert2_dist_sweetalert2_all_b240e9f2.js",
  "static/chunks/node_modules_f51cf344._.js"
],
    source: "dynamic"
});
