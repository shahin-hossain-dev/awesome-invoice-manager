(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(admin)_components_partials_DashboardRoot_jsx_cb5480c1._.js",
  "static/chunks/_2b597022._.js"
],
    source: "dynamic"
});
