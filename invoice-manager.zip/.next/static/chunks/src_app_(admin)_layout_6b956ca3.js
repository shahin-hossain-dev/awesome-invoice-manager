(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_(admin)_components_partials_DashboardRoot_jsx_3fd901b8._.js",
  "static/chunks/_a65df177._.js"
],
    source: "dynamic"
});
