(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/app/(admin)/components/partials/DashboardRoot.jsx [app-client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0a5._.js",
  "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
  "static/chunks/node_modules_react-icons_md_index_mjs_78df2b41._.js",
  "static/chunks/node_modules_react-icons_cg_index_mjs_1c0b6008._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_io5_index_mjs_39106f7b._.js",
  "static/chunks/node_modules_react-icons_tb_index_mjs_f6a9920d._.js",
  "static/chunks/node_modules_react-icons_fa6_index_mjs_00e856c4._.js",
  "static/chunks/node_modules_react-icons_bi_index_mjs_cba0e860._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_ee38469a._.js",
  "static/chunks/src_app_(admin)_components_partials_643c22aa._.js",
  "static/chunks/src_app_(admin)_components_partials_DashboardRoot_jsx_7e98c06a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/app/(admin)/components/partials/DashboardRoot.jsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);