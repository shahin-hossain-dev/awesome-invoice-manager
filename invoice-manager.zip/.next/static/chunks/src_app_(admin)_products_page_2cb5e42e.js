(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_jodit-react_build_jodit-react_b5c0d70a.js",
  "static/chunks/src_0d04a86f._.js",
  "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
  "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
  "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
  "static/chunks/node_modules_sweetalert2_dist_sweetalert2_all_b240e9f2.js",
  "static/chunks/node_modules_2e952166._.js"
],
    source: "dynamic"
});
