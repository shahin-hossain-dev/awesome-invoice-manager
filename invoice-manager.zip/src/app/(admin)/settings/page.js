"use client";
import { Button, Form, Upload } from "antd";
import FormDiv from "../components/form/FormDiv";
import { Controller, useForm } from "react-hook-form";
import { FormInput } from "../components/form/fields";
import { UploadOutlined } from "@ant-design/icons";

const AppSettings = () => {
  const { register, control, handleSubmit, setValue } = useForm({
    // defaultValues: {
    //   firstName: "",
    //   select: {},
    // },
  });

  const onSubmit = (data) => {
    console.log(data);
  };

  return (
    <div>
      <div>
        <Form
          name="basic"
          // labelCol={{ span: 8 }}
          // wrapperCol={{ span: 16 }}
          // style={{ maxWidth: 600 }}
          initialValues={{ remember: true }}
          onFinish={handleSubmit(onSubmit)}
          autoComplete="off"
          layout="vertical"
          size="large"
          className=" !w-full  "
        >
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-y-4 lg:gap-4">
            <div className="col-span-3 relative ">
              <FormDiv title={"Product Information"}>
                <div>
                  <Controller
                    name="file"
                    control={control}
                    rules={{ required: "File is required" }}
                    render={({ field, fieldState }) => {
                      const { value, onChange } = field;

                      const handleChange = (info) => {
                        const latestFile = info.fileList.slice(-1);
                        onChange(latestFile);
                      };

                      return (
                        <Form.Item
                          label="Upload QR Code"
                          validateStatus={fieldState.error ? "error" : ""}
                          help={fieldState.error?.message}
                        >
                          <Upload
                            fileList={value || []} // controlled by RHF
                            onChange={handleChange}
                            beforeUpload={() => false} // prevent auto upload
                          >
                            <Button icon={<UploadOutlined />}>
                              Select File
                            </Button>
                          </Upload>
                        </Form.Item>
                      );
                    }}
                  />
                </div>

                <div className="flex items-center gap-2 lg:gap-4 w-full">
                  {/*  product name */}
                  <Controller
                    name="customerName"
                    control={control}
                    rules={{ required: "Customer name is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Customer Name"}
                        placeholder="Customer Name"
                        validateStatus={fieldState?.error ? "error" : ""}
                        help={fieldState?.error?.message}
                      />
                    )}
                  />
                  {/* company name */}
                  <Controller
                    name="company"
                    control={control}
                    rules={{ required: "Company  is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Company "}
                        placeholder="Company "
                        validateStatus={fieldState?.error ? "error" : ""}
                        help={fieldState?.error?.message}
                      />
                    )}
                  />
                </div>
                <div className="flex items-center gap-2 lg:gap-4 w-full">
                  {/*  email */}

                  <Controller
                    name="email"
                    control={control}
                    // rules={{ required: "Email is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Email"}
                        placeholder="Email"
                        // validateStatus={fieldState?.error ? "error" : ""}
                        // help={fieldState?.error?.message}
                      />
                    )}
                  />
                  {/* product code */}
                  <Controller
                    name="phone"
                    control={control}
                    rules={{ required: "Phone no. is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Phone"}
                        placeholder="Phone"
                        validateStatus={fieldState?.error ? "error" : ""}
                        help={fieldState?.error?.message}
                      />
                    )}
                  />
                </div>
                <div>
                  <Controller
                    name="address"
                    control={control}
                    rules={{ required: "Address no. is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Address"}
                        placeholder="Address"
                        validateStatus={fieldState?.error ? "error" : ""}
                        help={fieldState?.error?.message}
                      />
                    )}
                  />
                </div>

                <div className="flex items-center gap-2 lg:gap-4 w-full">
                  {/*  city */}

                  <Controller
                    name="city"
                    control={control}
                    // rules={{ required: "Email is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"City"}
                        placeholder="City"
                        // validateStatus={fieldState?.error ? "error" : ""}
                        // help={fieldState?.error?.message}
                      />
                    )}
                  />
                  {/* product code */}
                  <Controller
                    name="postalCode"
                    control={control}
                    // rules={{ required: "Phone no. is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Postal Code"}
                        placeholder="Postal Code"
                        // validateStatus={fieldState?.error ? "error" : ""}
                        // help={fieldState?.error?.message}
                      />
                    )}
                  />
                </div>
                <div className="flex items-center gap-2 lg:gap-4 w-full">
                  {/*  State */}

                  <Controller
                    name="state"
                    control={control}
                    // rules={{ required: "Email is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"State"}
                        placeholder="State"
                        // validateStatus={fieldState?.error ? "error" : ""}
                        // help={fieldState?.error?.message}
                      />
                    )}
                  />
                  {/* Country */}
                  <Controller
                    name="country"
                    control={control}
                    // rules={{ required: "Phone no. is required" }}
                    render={({ field, fieldState }) => (
                      <FormInput
                        {...field}
                        // required={true}
                        size={"large"}
                        label={"Country"}
                        placeholder="Country"
                        // validateStatus={fieldState?.error ? "error" : ""}
                        // help={fieldState?.error?.message}
                      />
                    )}
                  />
                </div>

                <div className="mt-4">
                  <Button type="primary" htmlType="submit" className="!w-full">
                    Create Customer
                  </Button>
                </div>
              </FormDiv>
            </div>
          </div>
        </Form>
      </div>
    </div>
  );
};

export default AppSettings;

// const AccountSetting = () => {
//   const { isModalOpen, handleCancel, showModal } = useModalOpen();

//   return (
//     <div>
//       <h2>Reports</h2>
//       <Button onClick={showModal}>Modal Open</Button>
//       <Modal open={isModalOpen} onCancel={handleCancel}>
//         <h2>Some text Here</h2>
//         <h3>Reuseable Modal</h3>
//       </Modal>
//       <AccountOption />
//     </div>
//   );
// };

// export default AccountSetting;

// const AccountOption = () => {
//   const { isModalOpen, handleCancel, showModal } = useModalOpen();

//   return (
//     <div>
//       <h2>Account Options</h2>

//       <Button onClick={showModal}>Modal Open</Button>
//       <Modal
//         title={"Update Profile"}
//         open={isModalOpen}
//         onCancel={handleCancel}
//       >
//         <h2>Some text Here Two</h2>
//         <h3>Reuseable Modal Two</h3>
//       </Modal>
//     </div>
//   );
// };
