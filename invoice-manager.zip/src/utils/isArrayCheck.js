export const isArrayCheck = (isArr) => {
  if (Array.isArray(isArr)) {
    return true;
  }
  return false;
};
