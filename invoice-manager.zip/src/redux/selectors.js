// selectors.js
export const selectAuthToken = (state) => state.authSlice?.token || null;
